# Apex Dashboard — Claude Code Handoff
> Generated from UXMagic export. This is your source of truth for UI implementation.
> DO NOT reinterpret the design. Implement exactly as specified below.

---

## 🎯 What You're Building

A **MLM agent dashboard** (ProNet / Apex) with sidebar navigation, stats cards, commission chart, leaderboard, network tree, and activity feed. Mobile-responsive with a bottom nav on small screens.

---

## 📁 File Reference

The source HTML, CSS, and JS from UXMagic are included in this package:
- `source/index.html` — complete layout and component structure
- `source/styles.css` — CSS variables, glass effects, animations
- `source/script.js` — minimal JS (icon init, chart init, smooth scroll)

**Your job:** Convert these into React components (or Next.js pages) that match the source exactly.

---

## 🎨 Design Tokens (USE THESE EXACT VALUES)

### Colors
```js
// Tailwind custom config — extend theme with these
colors: {
  primary: {
    50: '#F5F3FF',
    100: '#EDE9FE',
    400: '#A78BFA',
    500: '#7C3AED',  // Electric Violet — main brand color
    600: '#6D28D9',
    700: '#5B21B6',
  },
  secondary: {
    50: '#ECFDF5',
    100: '#D1FAE5',
    400: '#34D399',
    500: '#10B981',  // Emerald Green — success/earnings
    600: '#059669',
  },
  neutral: {
    50: '#F9FAFB', 100: '#F3F4F6', 200: '#E5E7EB',
    300: '#D1D5DB', 400: '#9CA3AF', 500: '#6B7280',
    600: '#4B5563', 700: '#374151', 800: '#1F2937', 900: '#111827',
  },
  background: {
    50: '#F8FAFC',   // page background
    100: '#F1F5F9',
    white: '#FFFFFF',
  }
}
```

### Typography
```css
--font-heading-name: 'Inter';
--font-body-name: 'Inter';
--letter-spacing-heading: -0.02em;
```

### Spacing & Radius
```css
--radius-small: 0.5rem;   /* rounded-small = 8px */
--radius-large: 1rem;     /* rounded-large = 16px */
--space-base: 1rem;
```

### Shadows
```css
--shadow-custom: 0 4px 6px -1px rgba(0,0,0,0.05), 0 2px 4px -1px rgba(0,0,0,0.03);
--shadow-custom-hover: 0 10px 15px -3px rgba(0,0,0,0.08), 0 4px 6px -2px rgba(0,0,0,0.04);
```

### Glass Effects (critical — don't skip)
```css
/* .glass-panel — sidebar and header */
background: rgba(255, 255, 255, 0.85);
backdrop-filter: blur(12px);
border: 1px solid rgba(255, 255, 255, 0.6);

/* .glass-card — content cards */
background: rgba(255, 255, 255, 0.7);
backdrop-filter: blur(8px);
border: 1px solid rgba(255, 255, 255, 0.8);
box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03);

/* .glass-card:hover */
background: rgba(255, 255, 255, 0.95);
border-color: rgba(124, 58, 237, 0.2);
box-shadow: 0 10px 25px rgba(0, 0, 0, 0.05);
```

---

## 🧩 Component Breakdown

### 1. `<Sidebar>` (desktop only, hidden on mobile)
- Width: `w-64`, sticky, full height, `glass-panel` style
- Logo: gradient square icon (`from-primary-500 to-primary-600`) + "ProNet" text
- Profile card: avatar with gradient ring, rank badge ("Gold"), progress bar (75%), point labels
- Nav links: Dashboard (active), My Network, Earnings, Orders, Training, Settings
- Sign Out button at bottom
- Icons: lucide-react (`layout-dashboard`, `users`, `wallet`, `shopping-bag`, `graduation-cap`, `settings`, `log-out`, `hexagon`, `crown`)

### 2. `<TopBar>` (sticky header)
- Left: Logo (mobile only, hidden lg)
- Center: Search input with lucide `search` icon (hidden on mobile)
- Right: Bell (with red dot badge), Help circle, divider, username
- `glass-panel` style, `border-b border-neutral-200`

### 3. `<StatsGrid>` (4-col grid)
Four cards, each with:
- Label (uppercase, xs, neutral-500)
- Value (2xl bold)
- Icon (colored bg box)
- Trend badge (green % or static text)

| Card | Value | Icon | Color |
|------|-------|------|-------|
| Total Earnings | $12,450 | dollar-sign | secondary |
| Personal Volume | 850 PV | package | primary |
| Team Volume | 45,200 GV | users | blue |
| Pending | $1,240 | clock | orange |

Animation: `animate-slide-in` with 0/100/200/300ms delays.

### 4. `<CommissionBreakdown>` (2/3 width)
- Left: Doughnut chart (Chart.js) — cutout 75%, no legend
  - Colors: violet `#7C3AED`, emerald `#10B981`, blue `#3B82F6`, orange `#F97316`
  - Center text overlay: "Total" + "$12.4k"
- Right: 4 legend rows with colored dot, label, sublabel, dollar amount
  - Team Overrides $5,620, Personal Sales $3,240, Leadership Bonus $2,100, Fast Start $1,490

### 5. `<Leaderboard>` (1/3 width)
- Dropdown: "This Month" / "Last Month"
- 4 members: rank number, avatar, name, rank+GV, trend icon
- Row #3 = "You" — highlighted with `bg-primary-50 border border-primary-100`
- "View Full Leaderboard" button at bottom

### 6. `<NetworkTree>` (full width)
- Horizontal scroll on overflow
- Level 0: current user with gradient ring avatar
- Level 1: 4 nodes (Elena, Marcus, David, +3 more) connected by SVG/CSS lines
- Active nodes: colored border + green dot indicator
- Inactive nodes: grayscale image

### 7. `<ActivityFeed>` (2/3 width)
- Timeline with vertical connector lines between items
- 3 events: New Team Member, Rank Advancement, Order Shipped
- Icon circles with colored bg per event type

### 8. `<QuickActions>` (1/3 width)
- 2×2 grid of icon buttons: Share Link, New Order, Enroll Rep, Training
- Progress block at bottom: "Next Goal: Platinum", progress bar at 82%

### 9. `<MobileBottomNav>` (lg:hidden, fixed bottom)
- 5 tabs: Home, Network, [+ FAB button], Earnings, Profile
- Center FAB: gradient circle, elevated above bar

### 10. `<AnnouncementBanner>`
- Left border accent `border-l-4 border-l-primary-500`
- Calendar icon + title + description
- X dismiss button

---

## 📦 External Dependencies

```bash
npm install lucide-react chart.js react-chartjs-2
```

Or if using CDN in HTML:
```html
<script src="https://unpkg.com/lucide@latest"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
```

---

## 🗂️ Suggested React File Structure

```
/components
  /layout
    Sidebar.jsx
    TopBar.jsx
    MobileBottomNav.jsx
  /dashboard
    StatsGrid.jsx
    CommissionBreakdown.jsx
    Leaderboard.jsx
    NetworkTree.jsx
    ActivityFeed.jsx
    QuickActions.jsx
    AnnouncementBanner.jsx
/pages
  dashboard.jsx   (or app/dashboard/page.jsx for Next.js)
/styles
  globals.css     (paste glass-panel, glass-card, animate-slide-in from source/styles.css)
tailwind.config.js  (extend with design tokens above)
```

---

## ⚠️ Implementation Rules

1. **Do not change colors** — use exact hex values from design tokens
2. **Do not remove glass effects** — they are critical to the visual identity
3. **Match spacing exactly** — use the Tailwind classes from source HTML
4. **Keep lucide-react icons** — same icon names as in source
5. **Chart.js doughnut** — cutout at 75%, custom tooltip style (white bg, border)
6. **Mobile nav is FIXED bottom** — ensure content has `pb-24 lg:pb-8` padding
7. **Sidebar is sticky** — `sticky top-0 h-screen overflow-y-auto`
8. **Background glow blobs** — two `absolute` divs with `blur-[120px]`, positioned top-left and bottom-right of main content area

---

## 🚀 Build Order (Recommended)

1. Set up Tailwind config with design tokens
2. Add glass CSS to globals.css
3. Build `<Sidebar>` + `<TopBar>` + `<MobileBottomNav>` (layout shell)
4. Build `<StatsGrid>`
5. Build `<CommissionBreakdown>` with chart
6. Build `<Leaderboard>`
7. Build `<NetworkTree>`
8. Build `<ActivityFeed>` + `<QuickActions>`
9. Add `<AnnouncementBanner>`
10. Wire everything into `dashboard.jsx`
